#pragma once

double elemMod(element elemATK, element elemDEF);
