#pragma once
typedef enum{
  fire,
  ice,
  nature,
  earth,
  wind,
  spark,
  water,
  light,
  dark,
  null,
  voidal,
  none,
  special
} element;
