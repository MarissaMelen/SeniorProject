#pragma once
typedef enum{
  sword,
  spear,
  axe,
  fist,
  knife,
  bow,
  crossbow,
  firearm,
  nonmage,
  quickcast,
  custom
} weapon;
