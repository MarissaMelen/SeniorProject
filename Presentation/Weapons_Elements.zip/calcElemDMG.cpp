#include <iostream>
#include "element.hpp"
#include "calcElement.hpp"
using namespace std;

istream & operator >> (istream &i, element &e)
{
    //Read in weapon from command line
    string input;
    i >> input;
    
    //Make input lowercase
    for (int j=0; j<input.size(); j++)
    {
        input[j] = tolower(input[j]);
    }
    
    if (input == "fire")
        e = fire;
    else if (input == "ice")
        e = ice;
    else if (input == "nature")
        e = nature;
    else if (input == "earth")
        e = earth;
    else if (input == "wind")
        e = wind;
    else if (input == "spark")
        e = spark;
    else if (input == "water")
        e = water;
    else if (input == "light")
        e = light;
    else if (input == "dark")
        e = dark;
    else if (input == "null")
        e = null;
    else if (input == "void")
        e = voidal;
    else if (input == "none")
        e = none;
    else
        e = special;
    return i;
}



double checkElem(int natk, int ndef)
{
  element atkElem1, atkElem2, defElem1, defElem2;
  double totalElemMOD = 1;
  double mod1, mod2;
  mod1 = mod2 = 1;
  //this means one or both of them have no element, so we can just move on
  //even if they are "none" we still do this
  if(natk*ndef == 0)
    {
      totalElemMOD = 1;
    }

  //if there is one attacking and one defending, calculate mod
  else if(natk == 1 && ndef == 1)
    {
      cout << "What is attacking element? ";
      cin >> atkElem1;
      cout << "What is defending element? ";
      cin >> defElem1;
      totalElemMOD = elemMod(atkElem1, defElem1);
    }

  //with two attacking elements and one defending element
  //calculate each attacking element against the defending element
  //then multiply them together for final result
  else if(natk == 2 && ndef == 1)
    {
      cout << "What is the first attacking element? ";
      cin >> atkElem1;
      cout << "What is the second attacking element? ";
      cin >> atkElem2;

      cout << "What is the defending element? ";
      cin >> defElem1;

      mod1 = elemMod(atkElem1, defElem1);
      mod2 = elemMod(atkElem2, defElem1);
      totalElemMOD = mod1*mod2;
    }

  //if there are two defending and one attacking, calculation is same as 2 attack 1 defend
  else if(natk == 1 && ndef == 2)
    {
      cout << "What is the attacking element? ";
      cin >> atkElem1;

      cout << "What is the first defending element? ";
      cin >> defElem1;
      cout << "What is the second defending element? ";
      cin >> defElem2;
      
      mod1 = elemMod(atkElem1, defElem1);
      mod2 = elemMod(atkElem1, defElem2);
      totalElemMOD = mod1*mod2;
    }

  //this is for a two against two calculation
  //check the first attack against the first defense
  //check the second attack against the second defense
  //then multiply results together, so YES, order would matter
  //but that's the point
  else if(natk == 2 && ndef == 2)
    {
      cout << "What is first attacking element? ";
      cin >> atkElem1;
      cout << "What is second defending element? ";
      cin >> atkElem2;

      cout << "What is the first defending elment? ";
      cin >> defElem1;
      cout << "What is the second defencing element? ";
      cin >> defElem2;

      mod1 = elemMod(atkElem1, defElem2);
      mod2 = elemMod(atkElem2, defElem2);

      totalElemMOD = mod1*mod2;
    }

  return totalElemMOD;
}
/*

int main()
{
    double value = 0;
    int natk, ndef;
    natk = ndef = 3;
    while (((natk > 2)||(natk < 0)) && ((ndef > 2)||(ndef < 0)))
    {
        cout << "How many attacking elements? How many defending elements? ";
        cin >> natk >> ndef;
    }
    value = checkElem(natk, ndef);
    cout << "value = " << value << endl;
    
    
    return 0;
}

*/