#pragma once

double checkElem(int natk, int ndef);
