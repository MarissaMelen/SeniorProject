#pragma once

double damage(weapon weapontype, int roll, int baseDMG, int monsterARM, int monsterDEF, int monsterPWR, int monsterRES, double elementMOD);
